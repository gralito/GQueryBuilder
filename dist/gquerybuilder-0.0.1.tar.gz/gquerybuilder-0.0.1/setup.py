import setuptools


setuptools.setup()